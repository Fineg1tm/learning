/* Multi-dimensional arrays Project1 - Chess Board */

/* Global Variables */
var game = new Array(8);
var strMessage = "";
var blnWhite = true;

var arrFrom = new Array(2);
var arrTo = new Array(2);

var pieceUniq = ['b','k','n','p','q','r'];
var imageCache = [];
var docImages = [];
var str1 = "img/"; var str2 = "0.png"; var str3 = "1.png";

var $$ = function (id) {
    return document.getElementById(id);
}
var StartGame = function () {

	// Display White as current player
	$$("blackplay").removeAttribute("class");
	
  /*Create game board step1   r= rank or row,  f= file or column */

  //clear input boxes
  $$("from_coords").value = "";
  $$("to_coords").value = "";
  
  var gameRank0 = ['r','n','b','q','k','b','n','r'];
  var pawn = 'p';
  var PAWN = 'P';
  
  for (var r = 0; r < 8; r++) {
    game[r] = new Array(8);
	for (var f = 0; f < 8; f++) {
	    var elemId = r.toString() + f.toString();
	    var image = $$(elemId).lastChild;
		//var image = $$(elemId);
	    var piecew = str1.concat(gameRank0[f], str2);
	    var pieceb = str1.concat(gameRank0[f], str3);

		switch (r)
		{
			// back ranks 
			case 0:
				game[r][f] = gameRank0[f];
				image.setAttribute("src", piecew);
				image.setAttribute("class", "occupied");
				break;
			case 7:
				game[r][f] = gameRank0[f].toUpperCase();
				image.setAttribute("src", pieceb);
				image.setAttribute("class", "occupied");
				break;
			// pawn ranks
			case 1:
				game[r][f] = pawn;
				image.setAttribute("src", "img/p0.png");
				image.setAttribute("class", "occupied");
				break;
			case 6:
				game[r][f] = PAWN;
				image.setAttribute("src", "img/p1.png");
				image.setAttribute("class", "occupied");
				break;
			default:
				game[r][f] = "";
				image.setAttribute("src", "");
				image.removeAttribute("class");
		} 
		//enter generated value into div (use generated id)
		
		var elemVal = "box" + r.toString() + f.toString();
		//$$(elemId).firstChild.nodeValue = elemVal;
	}
  }
	// enable the Move/Play buttons
	$$("btnMove").disabled = false;
	$$("btnPlay").disabled = false;
}
var MakeMove = function () {
	//Move piece from Location to Location
	// call to check move validity against game state board
	// then carry out move
	// validate the from and to coordinates

	// from and to coordinates must be on the board (within range)
	// to coordinate must be empty
	// from coordinate must NOT be empty
	// from coordinate must be the current players piece (check case)

	if (IsValidMove($$("from_coords").value, $$("to_coords").value))
	{
		//clear previous message
		strMessage = "*";
		
		//model change (2 steps)
		//move piece to new position
		game[arrTo[0]][arrTo[1]] = game[arrFrom[0]][arrFrom[1]];
		//clear old position
		game[arrFrom[0]][arrFrom[1]] = "";
		
		//view change DOM
		var strSrc = "";
		
		var frElemId = arrFrom[0].toString() + arrFrom[1].toString();
		var frImage = $$(frElemId).lastChild;
		var toElemId = arrTo[0].toString() + arrTo[1].toString();
	  	var toImage = $$(toElemId).lastChild;
		
		$("#"+frElemId+" > img").stop().animate({opacity:'0'});
		strSrc = frImage.getAttribute("src");
		//$('#myText').fadeOut();
		//toImage.hide('fast');
		$("#"+toElemId+" > img").stop().animate({opacity:'0'},function(){
                $(this).attr('src',strSrc);
        }).load(function(){
                $(this).stop().animate({opacity:'1'});
        });
		//toImage.setAttribute("src", strSrc);
		toImage.setAttribute("class", "occupied");
		//toImage.show('slow');
		
		//frImage.hide('slow');
		frImage.setAttribute("src", "");
		frImage.removeAttribute("class");
	}
	else
	{
		
	}
	// update user message
	$$("errMessage").firstChild.nodeValue = strMessage;
	
	// toggle play display
	var whiteH = $$("whiteplay");
	var blackH = $$("blackplay");
	
	if (blnWhite)
	 {
		blnWhite = false;
		whiteH.removeAttribute("class");
		blackH.setAttribute("class","current");
	 }
	else
	 {
		blnWhite = true;
		blackH.removeAttribute("class");
		whiteH.setAttribute("class","current");
	 }
}
var GamePlayer = function () {
	//Start Interval Timer and get moves from an array
	//start the automated game
	var moveCounter = 0;
	  // 2-D Array Chess game starting state
  var game1 =
  [['1,0','3,0'],
   ['6,7','4,7'],
   ['0,1','2,2'],
   ['7,6','5,5'],
   ['0,0','2,0'],
   ['7,7','5,7'],
   ['1,6','2,6'],
   ['6,1','5,1'],
   ['0,5','2,7'],
   ['7,2','5,0']];
	var timer = setInterval(
		function () {

			if (moveCounter >= game1.length)
			{ clearInterval(timer); } /*stops the timer when game array exhausted */
			//populate input boxes and cause move button to be clicked
			$$("from_coords").value = game1[moveCounter][0];
			$$("to_coords").value = game1[moveCounter][1];
			//moveCounter = (moveCounter + 1) % game1.length;
			moveCounter ++;
			$$("btnMove").click();
			},
			5000);
}

function IsValidMove(fromCoords, toCoords)
{
	arrFrom = ConvertCoord(fromCoords);
	if (!((arrFrom[0] >= 0 && arrFrom[0] <= 7) &&
		(arrFrom[1] >= 0 && arrFrom[0] <= 7))
		)
		{
		strMessage = "Invalid FROM coordinates";
		return false;
		}
	arrTo = ConvertCoord(toCoords);
	if (!((arrTo[0] >= 0 && arrTo[0] <= 7) &&
		(arrTo[1] >= 0 && arrTo[0] <= 7))
		)
		{
		strMessage = "Invalid TO coordinates";
		return false;
		}
	//continue validating move ...
	
	
	return true;
}
function ConvertCoord(strCoords) {
	var arrCoord = strCoords.split(',');
	arrCoord[0] = parseInt(arrCoord[0]);
	arrCoord[1] = parseInt(arrCoord[1]);
	return arrCoord;
}
window.onload = function () {
    //LoadImages();
    $$("btnStart").onclick = StartGame;
	$$("btnMove").onclick = MakeMove;
	$$("btnPlay").onclick = GamePlayer;
    $$("from_coords").focus;
}