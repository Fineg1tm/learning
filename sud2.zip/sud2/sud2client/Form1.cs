﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;

namespace sud2client
{
    public partial class Form1 : Form
    {
        localhost.Service SudokuService = new localhost.Service();
   
        Random rng = new Random((int)DateTime.Now.Ticks & 0x0000FFFF);
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Call NewPuzzle, should return a populated 9 x 9 int array

            dgvPuzzle.Rows.Clear();

            dgvPuzzle.ColumnCount = 9;
            int[,] puzzle = new int[9, 9];

            //Begin changes to convert to WebService call.
            //NewPuzzle(puzzle);  // populated array returned
            int[] puzzle1D;
            puzzle1D = SudokuService.NewPuzzle();
            //Convert to 2D
            int i = 0;
            for (int r = 0; r < 9; r++)
                for (int c = 0; c < 9; c++)
                {
                    puzzle[r, c] = puzzle1D[i];
                    i++;
                }
            //End Changes to convert to Webservice call

            //Display values in grid on the form
            Display(puzzle);

            puzzle = null;

        }

        // Stays on client
        //**********************************************
        private void Display(int[,] puzzle)
        //**********************************************
        {
            var rowCount = puzzle.GetLength(0);
            var rowLength = puzzle.GetLength(1);

            for (int rowIndex = 0; rowIndex < rowCount; ++rowIndex)
            {
                var row = new DataGridViewRow();

                for (int columnIndex = 0; columnIndex < rowLength; ++columnIndex)
                {
                    DataGridViewTextBoxCell cell1 = new DataGridViewTextBoxCell();
                    cell1.Value = puzzle[rowIndex, columnIndex];
                    row.Cells.Add(cell1);
                }
                dgvPuzzle.Rows.Add(row);
            }
            //dgvPuzzle, cell sizing for display.
            dgvPuzzle.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvPuzzle.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvPuzzle.Visible = true;
        }

        private void btnFinish_Click(object sender, EventArgs e)
        {
            // Remove selected cells from display
            int ease = 0;
            ease = (int)trkDiff.Value;
            switch (ease)
            {
                case 0:
                    ease = 9;
                    break;
                case 1:
                    ease = 12;
                    break;
                case 2:
                    ease = 15;
                    break;
                case 3:
                    ease = 17;
                    break;
                case 4:
                    ease = 19;
                    break;
                case 5:
                    ease = 21;
                    break;
            }

            int cellX = 0;
            int cellY = 0;
            int cell = 0;
            for (int i = 0; i < ease; i++)
            {

                cell = rng.Next(0, 80);
                int row = cell / 8;

                int col = (cell % 8);
                if (col == 0)
                {
                    col = 8;
                }
                else
                {
                    col--;
                }
                    
                cellX = rng.Next(0, 8);
                cellY = rng.Next(0, 8);
                dgvPuzzle.Rows[row].Cells[col].Value = " ";
            }
        }
    }
}